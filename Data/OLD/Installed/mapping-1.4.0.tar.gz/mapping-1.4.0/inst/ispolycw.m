## Copyright (C) 2017-2020 Philip Nienhuis
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <http://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {Function File} {@var{iscw} =} ispolycw (@var{X}, @var{Y})
## Check if a polygon has clockwise winding direction.
##
## Input can comprise an Nx2 or Nx3 array of vertex coordinates (X, Y)
## or (X, Y, Z), or separate X and Y (row or column) vectors.  The
## input matrix or -vectors can comprise several polygons or polygon
## parts separated by NaN rows.
##
## ispolycw is a mere wrapper around function clipper in the
## geometry package.
##
## @seealso{closePolygonParts}
## @end deftypefn

## Author: Philip Nienhuis <pr.nienhuis@users.sf.net>
## Created: 2017-11-10

function [iscw] = ispolycw (varargin)

  if (isempty (which ("clipper")))
    error ("ispolycw: function clipper not found.\n\          OF geometry \
package installed and loaded?");
  endif

  ## Check input matrices
  if (nargin == 1 && isnumeric (varargin{1}) && size (varargin{1}, 2) == 2)
    inpol = varargin{1};
  elseif (nargin == 1 && isnumeric (varargin{1}) && size (varargin{1}, 2) >= 3)
    ## Input matrix has a column with Z-values => delete it
    varargin{1}(:, 3) = [];
    inpol = varargin{1}(:, 1:2);
  elseif (numel (varargin) >= 2)
    ## We hope the first two are vectors. Morph into Nx2 array
    if (isnumeric (varargin{1}) && isnumeric (varargin{2}))
      if (isrow (varargin{1}))
        varargin{1} = varargin{1}';
      endif
      if (isrow (varargin{2}))
        varargin{2} = varargin{2}';
      endif
      if (numel (varargin{1}) == numel (varargin{2}))
        inpol = [varargin{1} varargin{2}];
      else
        error ("ispolycw: X and Y vectors should be of equal length");
      endif
    else
      error ("ispolycw: numeric input expected");
    endif
  else
    print_usage ();
  endif

  inpol = __dbl2int64__ (inpol);

  ## Just find out orientation of polygons
  iscw = ! clipper (inpol);

endfunction


%!test
%! pol = [1 1 1; 5 1 1; 3 4 2; 1 1 1];
%! lop = flipud (pol);
%! pollop = [ pol; NaN(1, 3); lop ];
%! assert (ispolycw (pollop), [0; 1], 1e-10);
%! assert (ispolycw (pollop(:, 1), pollop(:, 2), pollop(:, 3)), [0; 1], 1e-10);
%! assert (ispolycw (pollop(:, 1)', pollop(:, 2)', pollop(:, 3)'), [0; 1], 1e-10);
