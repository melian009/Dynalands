## Copyright (C) 2019 David Legland
## All rights reserved.
## 
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions are met:
## 
##     1 Redistributions of source code must retain the above copyright notice,
##       this list of conditions and the following disclaimer.
##     2 Redistributions in binary form must reproduce the above copyright
##       notice, this list of conditions and the following disclaimer in the
##       documentation and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ''AS IS''
## AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
## IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
## ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
## ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
## DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
## SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
## CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
## OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
## OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
## 
## The views and conclusions contained in the software and documentation are
## those of the authors and should not be interpreted as representing official
## policies, either expressed or implied, of the copyright holders.

function points = polyhedronSlice(nodes, faces, plane)
%POLYHEDRONSLICE Intersect a convex polyhedron with a plane.
%
%   SLICE = polyhedronSlice(NODES, FACES, PLANE)
%   NODES: a Nx3 array
%   FACES: either a cell array or a Nf*3 or Nf*4 array
%   PLANE: a plane representation [x0 y0 z0 dx1 dy1 dz1 dx2 dy2 dz2].
%   return the intersection polygon of the polyhedra with the plane, in the
%   form of a set of ordered points.
%
%   Works only for convex polyhedra.
%
%   Example
%   polyhedronSlice
%
%   See also
%   polyhedra, clipConvexPolyhedronHP, intersectPlaneMesh
%

% ------
% Author: David Legland
% e-mail: david.legland@nantes.inra.fr
% Created: 2007-09-18,    using Matlab 7.4.0.287 (R2007a)
% Copyright 2007 INRA - BIA PV Nantes - MIAJ Jouy-en-Josas.

% if faces is a numeric array, convert it to cell array
if isnumeric(faces)
    faces2 = cell(size(faces, 1), 1);
    for f = 1:length(faces2)
        faces2{f} = faces(f,:);
    end
    faces = faces2;
else
    % ensure we have face with horizontal vectors...
    for f = 1:length(faces)
        face = faces{f};
        faces{f} = face(:)';
    end
end

% compute edges of the polyhedron
inds = zeros(0, 2);
for f = 1:length(faces)
    face = faces{f}';
    inds = [inds ; sort([face face([2:end 1])], 2)]; %#ok<AGROW>
end
inds = unique(inds, 'rows');
edges = [nodes(inds(:,1), :) nodes(inds(:,2), :)];

% intersection of edges with plane
points = intersectEdgePlane(edges, plane);
points = points(sum(isfinite(points), 2)==3, :);

if ~isempty(points)
    points = angleSort3d(points);
end
